// employee class for main class
public class employee {
	String name = new String("Saurabh");
	int age=23;
	String city = new String("Chennai");

	public void display() {
		System.out.println("\nThe name is " + name);
		System.out.println("The age is " + age);
		System.out.println("The city is " + city);
	}
}
