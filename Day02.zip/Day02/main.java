// main class to display employee details
class main {
	public static void main(String[] args) {

		employee e1 = new employee();
		employee e2 = new employee();
		e1.display();
		e2.display();
	}
}
